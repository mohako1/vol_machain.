#include "MainWindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QByteArray>
#include <QDebug>
#include <QRegularExpression>


int number = 0;
QString memory = " ";
QByteArray fileMemory; // Memory buffer to hold the file content

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {
    ui->setupUi(this);
    connectSignals();
    setStyleSheet("QWidget { background-color: #f3e5f5; }"
                  "QLabel#titleLabel { color: #5e35b1; font-size: 24px; font-weight: bold; padding: 10px; }");


}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::connectSignals() {
    connect(ui->execbtn, &QPushButton::clicked, this, &MainWindow::on_execbtn_clicked);
}

void MainWindow::on_execbtn_clicked() {
    simulator.loadInstructionsFromFile("instructions.txt"); // Adjust the file path as needed
    simulator.execute();
}
void MainWindow::on_loadbtn_clicked() {
    // Set default value for x
    bool ok;
    int x = ui->startingValueEdit->text().isEmpty() ? 1 : ui->startingValueEdit->text().toInt(&ok);
    if (!ok || x <= 0) x = 1; // If conversion fails or x is not positive, default to 1

    // Open file dialog to select input file
    QString fileName = QFileDialog::getOpenFileName(this, "Open File", "", "Text Files (*.txt);;All Files (*)");
    if (fileName.isEmpty()) {
        return; // No file selected
    }

    // Open the selected file
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open the file.");
        return;
    }

    // Prepare memory
    QStringList localMemory;
    for (int i = 0; i < 256; ++i) {
        localMemory.append("Empty");
    }

    QStringList hexValues;
    QTextStream in(&file);

    // Read hex values and process them
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList tokens = line.split(QRegularExpression("\\s+")); // Split by whitespace

        // Filter out empty tokens manually
        for (const QString &token : tokens) {
            if (!token.isEmpty() && token.length() == 4 && token.contains(QRegularExpression("^[0-9A-Fa-f]{4}$"))) {
                // Split the token into two 2-digit hex values
                QString highByte = token.mid(0, 2); // First two digits
                QString lowByte = token.mid(2, 2); // Last two digits

                // Add the two bytes to hexValues
                hexValues.append(highByte);
                hexValues.append(lowByte);
            }
        }
    }
    file.close();

    // Populate local memory starting from the index x
    for (int i = 0; i < hexValues.size() && (x + i) < 256; ++i) {
        QString binaryValue = QString::number(hexValues[i].toInt(nullptr, 16), 2).rightJustified(8, '0'); // Use 8 bits for each byte
        localMemory[x + i] = QString("%1 (Hex: %2)").arg(binaryValue, hexValues[i].toUpper());
    }

    // Show memory values
    ui->outputDisplay->clear(); // Clear previous output
    for (int i = 0; i < 256; ++i) {
        ui->outputDisplay->append(QString("Memory[%1] = %2").arg(i).arg(localMemory[i]));
    }
}

void MainWindow::displayInstruction(int pc, const QString& instruction) {
    // Display the instruction in a suitable widget, e.g., QTextEdit or QLabel
    ui->textEdit->append("PC: " + QString::number(pc) + " | Instruction: " + instruction);
}
