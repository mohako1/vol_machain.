#include "simulator.h"
#include <fstream>
#include <sstream>

Simulator::Simulator(QObject *parent) : QObject(parent), programCounter(0) {
    // Initialize memory and registers as needed
}

void Simulator::loadInstructionsFromFile(const std::string& filename) {
    std::ifstream infile(filename);
    if (!infile) {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return;
    }

    std::string line;
    while (std::getline(infile, line)) {
        // Process the line into a vector of ints
        std::vector<int> instruction(4);
        for (int i = 0; i < 4; ++i) {
            instruction[i] = std::stoi(line.substr(i, 1), nullptr, 16);
        }
        processInstruction(instruction);
    }
}

void Simulator::execute() {
    static int inst_num = 0;

    while (programCounter < memory.size()) {
        std::vector<int> v(4);
        for (int i = 0; i < 4; ++i) {
            v[i] = memory.getCell(programCounter)[i]; // Assuming memory.getCell returns a string
        }

        QString instructionStr = QString::fromStdString(
            alu.dec_hex(v[0]) + alu.dec_hex(v[1]) + alu.dec_hex(v[2]) + alu.dec_hex(v[3])
            );

        if (memory.getCell(programCounter)[0] == '1') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            cu.load(v[1], v[2] * 16 + v[3], registers, memory);
        } else if (memory.getCell(programCounter)[0] == '2') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            cu.load(v[1], v[2] * 16 + v[3], registers);
        } else if (memory.getCell(programCounter)[0] == '3') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            cu.store(v[1], v[2] * 16 + v[3], registers, memory);
        } else if (memory.getCell(programCounter)[0] == '3') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            cu.move(v[2], v[3], registers);
        } else if (memory.getCell(programCounter)[0] == '5') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            alu.addtows(v[1], v[2], v[3], registers);
        } else if (memory.getCell(programCounter)[0] == '6') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            alu.add(v[1], v[2], v[3], registers);
        } else if (memory.getCell(programCounter)[0] == 'B') {
            cu.jump(v[1], v[2] * 16 + v[3], registers, programCounter);
        } else if (memory.getCell(programCounter)[0] == 'C') {
            inst_num++;
            std::cout << "pc: " << inst_num << " | Instruction: " << instructionStr.toStdString() << std::endl;
            cu.halt(programCounter);
        }

        emit instructionProcessed(inst_num, instructionStr);
    }
}

void Simulator::processInstruction(const std::vector<int>& instruction) {
    // Implement the instruction processing logic here
    // For example:
    std::cout << "Processing instruction: " << instruction[0] << std::endl;
}
