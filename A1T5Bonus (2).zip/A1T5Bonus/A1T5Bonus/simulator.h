#ifndef SIMULATOR_H
#define SIMULATOR_H

#include <vector>
#include <iostream>
#include <QObject>
#include "Register.h"
#include "Memory.h"
#include "Alu.h"
#include "Cu.h"

class Simulator : public QObject {
    Q_OBJECT

public:
    explicit Simulator(QObject *parent = nullptr);
    void loadInstructionsFromFile(const std::string& filename);
    void execute();

private:
    Register registers;
    Memory memory;
    int programCounter;
    Alu alu;
    Cu cu;

    void processInstruction(const std::vector<int>& instruction);

signals:
    void instructionProcessed(int pc, const QString& instruction);
};

#endif // SIMULATOR_H
