#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Simulator.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    Simulator simulator;
    void connectSignals();


private slots:
    void on_execbtn_clicked();
    void on_loadbtn_clicked();
    void displayInstruction(int pc, const QString& instruction);


};

#endif // MAINWINDOW_H
